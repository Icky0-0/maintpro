MAINTPRO — MAINTENANCE WORK ORDER REPORT ASSISTANT

FILES
- index.html: the complete standalone web app.

HOW TO USE
1. Open index.html in a modern web browser.
2. Enter the work order number, total labor hours, number of visits, and report details.
3. Tap Generate report, then Copy for AppFolio.
4. Open the matching work order in AppFolio and paste the report into Notes.
5. Save report if you want it kept in this browser on this device.

IMPORTANT
- This demo does not connect to AppFolio or submit work orders.
- Saved reports remain in the browser's local storage on the device/browser used. They are not synced to other devices and can be lost if browser data is cleared.
- For a public shareable link, publish index.html using a static hosting service such as GitHub Pages. Company approval and AppFolio API access would be needed before adding direct submission.
